require 'test_helper'

class StoreHelperTest < ActionView::TestCase
end
